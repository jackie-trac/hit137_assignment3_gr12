import pygame
import math
import random

from pygame.locals import (
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    K_x,
    KEYDOWN,
    KEYUP,
    K_SPACE,
    QUIT,
)

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
HALF_WIDTH = SCREEN_WIDTH // 2
HALF_HEIGHT = SCREEN_HEIGHT // 2

# Set up the clock
clock = pygame.time.Clock()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Load images
def load_image(path):
    img = pygame.image.load('Sprites/' + path)
    img.set_colorkey((0, 0, 0))
    return img

# Animation function
def animation(lst, pos):
    return lst[pos % len(lst)]

def draw_tiles(tile, x, y, w, h):
    rect = pygame.Rect(x, y, w, h)
    surface = pygame.Surface(rect.size)
    i_count = math.ceil(w / 16)
    j_count = math.ceil(h / 16)
    for j in range(j_count):
        for i in range(i_count):
            surface.blit(tile, (i * 16, j * 16))
    screen.blit(surface, (x, y))

# Load player images
Still = load_image('Standing.png')
gunL = load_image('Lgun.png')
gunR = load_image('Rgun.png')
Lwalk = [load_image('LW1.png'), load_image('LW2.png'), load_image('LW3.png'), load_image('LW4.png')]
Rwalk = [load_image('RW1.png'), load_image('RW2.png'), load_image('RW3.png'), load_image('RW4.png')]
Climb = [load_image('Climb1.png'), load_image('Climb2.png')]

# Load backrounds
backgrounds = [load_image('Backgrounds/Background1.png'), load_image('Backgrounds/Background2.png'), load_image('Backgrounds/Background3.png')]

# Load floors and walls
floors = [load_image('Tiles/Floor1.png'), load_image('Tiles/Floor2.png'), load_image('Tiles/Floor3.png')]
walls = [load_image('Tiles/Wall1.png'), load_image('Tiles/Wall2.png'), load_image('Tiles/Wall3.png')]

# Load enemies
enemies = [load_image('Enemies/Enemy1.png'), load_image('Enemies/Enemy2.png'), load_image('Enemies/Enemy3.png')]

# Initialize player attributes
f = 0 
surf = Still
rect = surf.get_rect()
rect.topleft = (0, 0)  # Initial position

# Initialize hitbox
hitbox_width = 21
hitbox_height = 70
hitbox = pygame.Rect(
    rect.centerx - hitbox_width // 2,
    rect.centery - hitbox_height // 2,
    hitbox_width,
    hitbox_height
)

# Initialize camera position
camera_x = rect.centerx - HALF_WIDTH
camera_y = rect.centery - HALF_HEIGHT

# Jumping variables
is_jumping = False
jump_speed = -15
gravity = 1
yspeed = 0
xspeed = 0

# Boolean variables for movement
up = False
down = False
left = False
right = False
faced_left = True
Shoot = False
space = False
grounded = False
platform = False

# Create walls and floors for collision
walls_rects = [pygame.Rect(200, -40, 100, 50), pygame.Rect(500, -30, 100, 50)]
floor_rect = pygame.Rect(0, 70, SCREEN_WIDTH*5, 32)  # A floor at the bottom

# Randomly place an enemy
enemy_rect = pygame.Rect(random.randint(0, SCREEN_WIDTH - 50), random.randint(0, SCREEN_HEIGHT - 100), 50, 50)

while True:
    for event in pygame.event.get():
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                quit()
            if event.key == K_UP:
                up = True
            if event.key == K_DOWN:
                down = True
            if event.key == K_LEFT:
                left = True
                faced_left = True
            if event.key == K_RIGHT:
                right = True
                faced_left = False
            if event.key == K_x:
                Shoot = True
            if event.key == K_SPACE:
                space = True
        elif event.type == KEYUP:
            if event.key == K_UP:
                up = False
            if event.key == K_DOWN:
                down = False
            if event.key == K_LEFT:
                left = False
            if event.key == K_RIGHT:
                right = False
            if event.key == K_x:
                Shoot = False
            if event.key == K_SPACE:
                space = False
        elif event.type == QUIT:
            quit()

    screen.fill((100, 100, 100))
    
    if up:
        yspeed = 0
        f += 0.25
        surf = animation(Climb, math.floor(f))
        rect.move_ip(0, -5)
    elif down:
        yspeed = 0
        f += 0.25
        surf = animation(Climb, math.floor(f))
        rect.move_ip(0, 5)
    else:
        if Shoot:
            surf = gunL if faced_left else gunR
        else:
            if left and not right:
                f += 0.25
                surf = animation(Lwalk, math.floor(f))
                xspeed = -5
            elif right and not left:
                f += 0.25
                surf = animation(Rwalk, math.floor(f))
                xspeed = 5
            else:
                xspeed = 0
                f = 0
                surf = Still
            rect.move_ip(xspeed, 0)

        if space and grounded == True:
            yspeed = -15
            grounded = False
    if grounded == False:
        yspeed += gravity  # Apply gravity
    else:
        yspeed = 0

    # Create a rectangle for the next position
    next_ypos = hitbox.move(0, yspeed)

    # Check for collision with the floor rectangle
    if next_ypos.colliderect(floor_rect):
        # Adjust position to be on top of the floor
        rect.bottom = floor_rect.top  # Snap to the top of the floor
        grounded = True  # Set grounded to True if on the floor
    else:
        rect.move_ip(0, yspeed)  # Apply vertical movement if no collision


    next_xpos = hitbox.move(xspeed, 0)
    next_pos = hitbox.move(xspeed, yspeed)
    for wall in walls_rects:
        if next_pos.colliderect(wall):
            overlap_xrect = next_xpos.clip(wall)  # Get the overlapping rectangle
            overlap_xarea = overlap_xrect.width * overlap_xrect.height
            overlap_yrect = next_ypos.clip(wall)  # Get the overlapping rectangle
            overlap_yarea = overlap_yrect.width * overlap_yrect.height
            # Check from which side the collision occurred and adjust position
            if overlap_xarea >= overlap_yarea:
                if next_ypos.bottom > wall.top and next_ypos.top < wall.top:  # Top collision
                    rect.bottom = wall.top
                    grounded = True
                    platform = True
                else:  # Bottom collision
                    rect.top = wall.bottom
                    platform = False
            else:
                if next_pos.right > wall.left and next_pos.left < wall.left:  # Left collision
                    rect.right = wall.left
                else:  # Right collision
                    rect.left = wall.right
                platform = False
    # Update hitbox position to center on the player
    hitbox.center = rect.center

    # Update camera position smoothly
    target_camera_x = rect.centerx - HALF_WIDTH
    target_camera_y = rect.centery - HALF_HEIGHT
    camera_x += (target_camera_x - camera_x) * 0.1  # Smooth interpolation
    camera_y += (target_camera_y - camera_y) * 0.1

    # Draw background, floors, and walls
    screen.fill((100, 100, 100))
    
    # Draw floor
    x, y, w, h = floor_rect
    draw_tiles(floors[0], x - camera_x, y - camera_y, w, h)

    # Draw walls
    for wall in walls_rects:
        x, y, w, h = wall
        draw_tiles(walls[0], x - camera_x, y - camera_y, w, h)

    # Draw enemy
    screen.blit(enemies[0], (enemy_rect.x - camera_x, enemy_rect.y - camera_y))  # Offset by camera

    # Draw player and hitbox
    screen.blit(surf, (rect.x - camera_x, rect.y - camera_y))  # Offset the player by camera
    pygame.draw.rect(screen, (255, 0, 0), (hitbox.x - camera_x, hitbox.y - camera_y, hitbox.width, hitbox.height), 2)  # Draw hitbox
    
    # Collision detection
    if hitbox.colliderect(floor_rect) and platform == False:
        grounded = True
    else:
        if not next_ypos.colliderect(floor_rect):
            grounded = False

    if hitbox.colliderect(enemy_rect):
        print("Collision with enemy")

    pygame.display.flip()
    clock.tick(30)
